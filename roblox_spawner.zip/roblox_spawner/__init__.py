bl_info = {
    "name": "Roblox Bacon Spawner",
    "author": "tpwp",
    "version": (1, 1),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > Roblox",
    "description": "Spawn R6 Roblox characters",
    "category": "Object",
}

import bpy
import os


# APPEND COLLECTION FUNCTION
def append_collection(collection_name):

    addon_dir = os.path.dirname(__file__)
    blend_path = os.path.join(addon_dir, "roblox_characters.blend")

    collection_path = blend_path + "\\Collection\\"

    bpy.ops.wm.append(
        filepath=collection_path + collection_name,
        directory=collection_path,
        filename=collection_name
    )


# BACON MAN
class SPAWN_BACON_MAN(bpy.types.Operator):
    bl_idname = "roblox.spawn_bacon_man"
    bl_label = "Spawn Bacon Man"

    def execute(self, context):
        append_collection("BaconMan_R6")
        return {'FINISHED'}


# BACON WOMAN
class SPAWN_BACON_WOMAN(bpy.types.Operator):
    bl_idname = "roblox.spawn_bacon_woman"
    bl_label = "Spawn Bacon Woman"

    def execute(self, context):
        append_collection("BaconWoman_R6")
        return {'FINISHED'}


# NOOB
class SPAWN_NOOB(bpy.types.Operator):
    bl_idname = "roblox.spawn_noob"
    bl_label = "Spawn Noob"

    def execute(self, context):
        append_collection("Noob_R6")
        return {'FINISHED'}


# UI PANEL
class ROBLOX_PT_PANEL(bpy.types.Panel):
    bl_label = "Roblox Characters"
    bl_idname = "ROBLOX_PT_PANEL"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Bacons Importer"

    def draw(self, context):
        layout = self.layout

        layout.label(text="R6 Characters")

        layout.operator("roblox.spawn_bacon_man")
        layout.operator("roblox.spawn_bacon_woman")
        layout.operator("roblox.spawn_noob")


# REGISTER
classes = (
    SPAWN_BACON_MAN,
    SPAWN_BACON_WOMAN,
    SPAWN_NOOB,
    ROBLOX_PT_PANEL
)


def register():
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(classes):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()